interact_type = []
interact_target = []
interact_time = []

today = new Date();
curr_date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
curr_time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

interact_type.push("load")
interact_target.push("window")
interact_time.push(curr_date+" "+curr_time)

generateButton = document.getElementById("submit_btn")
englishLetters = ["a", "b", "c", "d", "e", "f", 
                      "g", "h", "i", "j", "k", "l", 
                      "m", "n", "o", "p", "q", "r", 
                      "s", "t", "u", "v", "w", "x", "y", "z"] 


generateButton.onclick = function(e){

    e.preventDefault()
    var eng_btns = document.getElementById("eng_btns")
    var englishLetterbtns = document.getElementsByClassName('englishLetterbtn')
    var numberInputValue = document.getElementById("number_btn").value
    var oldGeneratedRandomvalue = []

    if(eng_btns.textContent != ""){
        var child = eng_btns.lastElementChild;
        while(child){ 
            eng_btns.removeChild(child); 
            child = eng_btns.lastElementChild; 
        } 
    }

    for(var i=0; i<numberInputValue; i++){
        
        var randomNumber = Math.floor(Math.random()*26)

        if(oldGeneratedRandomvalue.indexOf(randomNumber) == -1){
            oldGeneratedRandomvalue.push(randomNumber) 
            var button = document.createElement("button");
            var letter = document.createTextNode(englishLetters[randomNumber]);
            button.appendChild(letter);
            button.setAttribute("class", "englishLetterbtn");
            button.setAttribute("data-value", englishLetters[randomNumber]);
            eng_btns.appendChild(button)
        }else{
            i--
        }
        
    }

    for(var i=0 ; i<englishLetterbtns.length; i++){
        englishLetterbtns[i].addEventListener('click',englishLetterbtn_click)
    }

   today = new Date();
   curr_date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
   curr_time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    
   interact_type.push("click")
   interact_target.push("generate button")
   interact_time.push(curr_date+" "+curr_time)
}

function englishLetterbtn_click(){
    imgCont =  document.querySelector('.imgContainer')
    imgCont.innerHTML = ""

    var letterName = this.getAttribute('data-value')
    var folderName = this.getAttribute('data-value')
    var imgName = this.getAttribute('data-value')+0
    var imagePath = folderName+"/"+imgName

    var img = document.createElement("img");
    img.setAttribute("src", "images/"+imagePath+".jpg");
    img.setAttribute("width", "100%");
    img.setAttribute("height", "430px%");
    imgCont.appendChild(img);


    today = new Date();
    curr_date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    curr_time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    
    interact_type.push("click")
    interact_target.push("letter button [ "+letterName+" ]")
    interact_time.push(curr_date+" "+curr_time)

}

function storeInteractions(type,target,time){
    table = document.querySelector(".userInteractions")
    table.style.visibility = "unset"

     this.type = type
     this.target = target
     this.time = time

     this.showInteractions = function(){
        for(var i = 0 ; i<this.type.length; i++){
            tr = document.createElement('tr')

            td_1 = document.createElement('td')
            td_1_text = document.createTextNode(this.type[i])
            td_1.appendChild(td_1_text)

            td_2 = document.createElement('td')
            td_2_text = document.createTextNode(this.target[i])
            td_2.appendChild(td_2_text)



            td_3 = document.createElement('td')
            td_3_text = document.createTextNode(this.time[i])
            td_3.appendChild(td_3_text)

            tr.appendChild(td_1)
            tr.appendChild(td_2)
            tr.appendChild(td_3)

            table.appendChild(tr)
        }

        interact_type = []
        interact_target = []
        interact_time = []

     }
 }

 interactionsLink = document.querySelector(".interactionsLink")
 interactionsLink.onclick = function(){
     var interactions = new storeInteractions(interact_type,interact_target,interact_time)
     interactions.showInteractions()
 }
